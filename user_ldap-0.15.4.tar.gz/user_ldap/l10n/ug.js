OC.L10N.register(
    "user_ldap",
    {
    "Users" : "ئىشلەتكۈچىلەر",
    "Groups" : "گۇرۇپپا",
    "Help" : "ياردەم",
    "Host" : "باش ئاپپارات",
    "Port" : "ئېغىز",
    "Password" : "ئىم",
    "Advanced" : "ئالىي",
    "Connection Settings" : "باغلىنىش تەڭشىكى",
    "Configuration Active" : "سەپلىمە ئاكتىپ"
},
"nplurals=1; plural=0;");
