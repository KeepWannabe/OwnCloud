OC.L10N.register(
    "user_ldap",
    {
    "Users" : "صارفین",
    "Help" : "مدد",
    "Password" : "پاسورڈ",
    "Advanced" : "ایڈوانسڈ"
},
"nplurals=2; plural=(n != 1);");
