OC.L10N.register(
    "user_ldap",
    {
    "Host" : "হোস্ট"
},
"nplurals=2; plural=(n != 1);");
