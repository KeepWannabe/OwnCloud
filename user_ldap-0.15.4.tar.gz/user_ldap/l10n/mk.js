OC.L10N.register(
    "user_ldap",
    {
    "Failed to clear the mappings." : "Неуспешно бришење на мапирањстс.",
    "Select groups" : "Одбери групи",
    "Confirm Deletion" : "Потврдете го бришењето",
    "Users" : "Корисници",
    "Groups" : "Групи",
    "Help" : "Помош",
    "Host" : "Домаќин",
    "You can omit the protocol, except you require SSL. Then start with ldaps://" : "Може да го скокнете протколот освен ако не ви треба SSL. Тогаш ставете ldaps://",
    "Port" : "Порта",
    "Password" : "Лозинка",
    "Back" : "Назад",
    "Continue" : "Продолжи",
    "Advanced" : "Напредно"
},
"nplurals=2; plural=(n % 10 == 1 && n % 100 != 11) ? 0 : 1;");
