OC.L10N.register(
    "user_ldap",
    {
    "Users" : "Usuarios",
    "Help" : "Ayuda",
    "Password" : "Clave"
},
"nplurals=2; plural=(n != 1);");
