OC.L10N.register(
    "user_ldap",
    {
    "Users" : "Pengguna",
    "Groups" : "Kumpulan",
    "Help" : "Bantuan",
    "Password" : "Kata laluan",
    "Back" : "Kembali",
    "Advanced" : "Maju"
},
"nplurals=1; plural=0;");
