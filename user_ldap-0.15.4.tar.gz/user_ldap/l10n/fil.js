OC.L10N.register(
    "user_ldap",
    {
    "Help" : "Tulong",
    "Password" : "Password"
},
"nplurals=2; plural=(n > 1);");
