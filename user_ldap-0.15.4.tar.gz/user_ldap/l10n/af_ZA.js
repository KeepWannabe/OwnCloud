OC.L10N.register(
    "user_ldap",
    {
    "Users" : "Gebruikers",
    "Help" : "Hulp",
    "Password" : "Wagwoord",
    "Continue" : "Gaan voort",
    "Advanced" : "Gevorderd"
},
"nplurals=2; plural=(n != 1);");
