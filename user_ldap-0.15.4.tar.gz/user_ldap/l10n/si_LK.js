OC.L10N.register(
    "user_ldap",
    {
    "Users" : "පරිශීලකයන්",
    "Groups" : "කණ්ඩායම්",
    "Help" : "උදව්",
    "Host" : "සත්කාරකය",
    "You can omit the protocol, except you require SSL. Then start with ldaps://" : "SSL අවශ්‍යය වන විට පමණක් හැර, අන් අවස්ථාවන්හිදී ප්‍රොටොකෝලය අත් හැරිය හැක. භාවිතා කරන විට ldaps:// ලෙස ආරම්භ කරන්න",
    "Port" : "තොට",
    "Password" : "මුර පදය",
    "Advanced" : "දියුණු/උසස්"
},
"nplurals=2; plural=(n != 1);");
