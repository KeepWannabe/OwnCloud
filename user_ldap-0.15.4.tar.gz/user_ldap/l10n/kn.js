OC.L10N.register(
    "user_ldap",
    {
    "Users" : "﻿ಬಳಕೆದಾರರು",
    "Groups" : "﻿ಗುಂಪುಗಳು",
    "Help" : "﻿ಸಹಾಯ",
    "Host" : "ಅತಿಥೆಯ-ಗಣಕ",
    "Port" : "﻿ರೇವು",
    "Password" : "ಗುಪ್ತ ಪದ",
    "Continue" : "﻿ಮುಂದುವರಿಸಿ"
},
"nplurals=1; plural=0;");
