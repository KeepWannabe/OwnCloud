OC.L10N.register(
    "user_ldap",
    {
    "Users" : "వాడుకరులు",
    "Help" : "సహాయం",
    "Password" : "సంకేతపదం",
    "Continue" : "కొనసాగించు",
    "Advanced" : "ఉన్నతం"
},
"nplurals=2; plural=(n != 1);");
