OC.L10N.register(
    "user_ldap",
    {
    "Password" : "Нууц үг"
},
"nplurals=2; plural=(n != 1);");
