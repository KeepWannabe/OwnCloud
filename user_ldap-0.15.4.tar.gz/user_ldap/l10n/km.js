OC.L10N.register(
    "user_ldap",
    {
    "Failed to delete the server configuration" : "លុប​ការ​កំណត់​រចនា​សម្ព័ន្ធ​ម៉ាស៊ីន​បម្រើ មិន​បាន​សម្រេច",
    "Do you really want to delete the current Server Configuration?" : "តើ​អ្នក​ពិត​ជា​ចង់​លុប​ការ​កំណត់​រចនាសម្ព័ន្ធ​ម៉ាស៊ីន​បម្រើ​បច្ចុប្បន្ន​មែន​ទេ?",
    "Confirm Deletion" : "បញ្ជាក់​ការ​លុប",
    "Users" : "អ្នកប្រើ",
    "Groups" : "ក្រុ",
    "Help" : "ជំនួយ",
    "Host" : "ម៉ាស៊ីន​ផ្ទុក",
    "Port" : "ច្រក",
    "Password" : "ពាក្យសម្ងាត់",
    "Back" : "ត្រឡប់ក្រោយ",
    "Continue" : "បន្ត",
    "Advanced" : "កម្រិត​ខ្ពស់"
},
"nplurals=1; plural=0;");
