OC.L10N.register(
    "user_ldap",
    {
    "Users" : "သုံးစွဲသူ",
    "Help" : "အကူအညီ",
    "Password" : "စကားဝှက်",
    "Advanced" : "အဆင့်မြင့်"
},
"nplurals=1; plural=0;");
