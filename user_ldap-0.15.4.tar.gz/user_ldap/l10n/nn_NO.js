OC.L10N.register(
    "user_ldap",
    {
    "Select groups" : "Vel grupper",
    "Users" : "Brukarar",
    "Groups" : "Grupper",
    "Help" : "Hjelp",
    "Host" : "Tenar",
    "Password" : "Passord",
    "Back" : "Tilbake",
    "Continue" : "Gå vidare",
    "Advanced" : "Avansert"
},
"nplurals=2; plural=(n != 1);");
