OC.L10N.register(
    "user_ldap",
    {
    "_%s group found_::_%s groups found_" : ["",""],
    "_%s user found_::_%s users found_" : ["",""]
},
"nplurals=2; plural=(n == 0 || n == 1 || (n > 10 && n < 100) ? 0 : 1;");
