OC.L10N.register(
    "user_ldap",
    {
    "Failed to delete the server configuration" : "Greška prilikom brisanja konfiguracije poslužitelja.",
    "Select groups" : "Označi grupe",
    "Users" : "Korisnici",
    "Groups" : "Grupe",
    "Help" : "Pomoć",
    "Host" : "Poslužitelj",
    "Port" : "Port",
    "Password" : "Lozinka",
    "Back" : "Natrag",
    "Continue" : "Nastavi",
    "Advanced" : "Napredno"
},
"nplurals=3; plural=n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2;");
