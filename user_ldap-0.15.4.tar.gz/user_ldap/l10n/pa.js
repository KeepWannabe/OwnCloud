OC.L10N.register(
    "user_ldap",
    {
    "Groups" : "ਗਰੁੱਪ",
    "Help" : "ਮਦਦ",
    "Password" : "ਪਾਸਵਰ",
    "Back" : "ਪਿੱਛੇ"
},
"nplurals=2; plural=(n != 1);");
