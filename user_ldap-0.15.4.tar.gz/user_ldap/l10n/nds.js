OC.L10N.register(
    "user_ldap",
    {
    "Host" : "Host",
    "Port" : "Port",
    "Password" : "Passwort",
    "Continue" : "Fortsetzen"
},
"nplurals=2; plural=(n != 1);");
