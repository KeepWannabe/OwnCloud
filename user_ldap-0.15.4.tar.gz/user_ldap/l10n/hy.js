OC.L10N.register(
    "user_ldap",
    {
    "Groups" : "Խմբեր",
    "Help" : "Օգնություն",
    "Host" : "Հոստ",
    "Password" : "Գաղտնաբառ",
    "Back" : "Հետ",
    "Continue" : "Շարունակել"
},
"nplurals=2; plural=(n != 1);");
