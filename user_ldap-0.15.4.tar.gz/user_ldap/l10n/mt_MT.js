OC.L10N.register(
    "user_ldap",
    {
    "_%s group found_::_%s groups found_" : ["","","",""],
    "_%s user found_::_%s users found_" : ["","","",""]
},
"nplurals=4; plural=(n==1 ? 0 : n==0 || ( n%100>1 && n%100<11) ? 1 : (n%100>10 && n%100<20 ) ? 2 : 3);");
