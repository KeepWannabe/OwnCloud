OC.L10N.register(
    "user_ldap",
    {
    "Users" : "Usatores",
    "Groups" : "Gruppos",
    "Help" : "Adjuta",
    "Password" : "Contrasigno",
    "Back" : "Retro",
    "Continue" : "Continuar",
    "Advanced" : "Avantiate"
},
"nplurals=2; plural=(n != 1);");
