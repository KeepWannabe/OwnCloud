OC.L10N.register(
    "user_ldap",
    {
    "Users" : "उपयोगकर्ता",
    "Help" : "सहयोग",
    "Password" : "पासवर्ड",
    "Advanced" : "उन्नत"
},
"nplurals=2; plural=(n != 1);");
