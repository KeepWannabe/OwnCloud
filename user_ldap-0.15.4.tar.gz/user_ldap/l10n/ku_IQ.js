OC.L10N.register(
    "user_ldap",
    {
    "Users" : "به‌كارهێنه‌ر",
    "Help" : "یارمەتی",
    "Password" : "وشەی تێپەربو",
    "Advanced" : "هه‌ڵبژاردنی پیشكه‌وتوو"
},
"nplurals=2; plural=(n != 1);");
