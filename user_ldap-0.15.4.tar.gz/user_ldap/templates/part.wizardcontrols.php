<div class="ldapWizardControls">
	<div class="stateIndicator"><span class="ldap_config_state_indicator"></span> <span class="ldap_config_state_indicator_sign"></span><div class="ldap_config_state_indicator_subline"></div></div>
	<button class="ldap_action_back invisible" name="ldap_action_back"><?php p($l->t('Back'));?></button>
	<button class="ldap_action_continue" name="ldap_action_continue"><?php p($l->t('Continue'));?></button>
</div>
